export interface IModalGiveAwardDocsItem {
  image: string;
  desc: string;
  date: string;
}
